package Model;

import Persistence.PersistenciaPersonajes;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class ColeccionPersonajes<T extends CSVSerializable> {

    private List<T> listaPersonajes = new ArrayList<>();

    public ColeccionPersonajes() {
        listaPersonajes = new ArrayList<>();
    }

    public void agregar(T item) {
        listaPersonajes.add(Objects.requireNonNull(item));
    }

    public void eliminar(int indice) {
        validarIndice(indice);
        listaPersonajes.remove(indice);
    }

    private void validarIndice(int index) {
        if (index < 0 || index >= tamanio()) {
            throw new IndexOutOfBoundsException("Indice invalido.");
        }
    }

    public int tamanio() {
        return listaPersonajes.size();
    }

    public T obtener(int indice) {
        validarIndice(indice);
        return listaPersonajes.get(indice);
    }

    public void ordenar(Comparator<? super T> criterio) {
        listaPersonajes.sort(criterio);
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> filtrado = new ArrayList<>();

        for (T elem : listaPersonajes) {
            if (criterio.test(elem)) {
                filtrado.add(elem);
            }
        }
        return filtrado;
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T hechizo : listaPersonajes) {
            accion.accept(hechizo);
        }
    }

    private List<T> copiarLista() {
        return new ArrayList<>(listaPersonajes);
    }

    public void guardarEnCSV(String path) {
        PersistenciaPersonajes.guardarPersonajesCSV((List<? extends Personaje>) listaPersonajes, path);
    }

    public List<Personaje> cargarDesdeCSV(String path) {
        List<Personaje> lista = PersistenciaPersonajes.cargarPersonajesCSV(path);
        
        listaPersonajes = (List<T>) lista;
        return (List<Personaje>) copiarLista();
    }

    public void guardarEnArchivo(String path) {
        PersistenciaPersonajes.serializarPersonajes((List<? extends Personaje>) listaPersonajes, path);
    }

    public List<Personaje> cargarDesdeArchivo(String path) {
        List<Personaje> lista = PersistenciaPersonajes.deserializarPersonajes(path);
        
        listaPersonajes = (List<T>) lista;
        return (List<Personaje>) copiarLista();
    }

}
