package Model;

import java.io.Serializable;

public class Personaje implements Comparable<Personaje>, CSVSerializable, Serializable {
    private final int id;
    private final String nombre;
    private final String creador;
    private final RolPersonaje rol;

    public Personaje(int id, String nombre, String creador, RolPersonaje rol) {
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.rol = rol;
    }

    @Override
    public String toString() {
        return "Personaje{" + "id=" + id + ", nombre=" + nombre + ", creador=" + creador + ", rol=" + rol + '}';
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCreador() {
        return creador;
    }

    public RolPersonaje getRol() {
        return rol;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Personaje other = (Personaje) obj;
        return this.id == other.id;
    }

    @Override
    public int compareTo(Personaje p) {
        return Integer.compare(id, p.id);
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + creador + "," + rol + "\n";
    }
    
    public static String toHeaderCSV() {
        return "id,nombre,creador,rol\n";
    }
    
    public static Personaje fromCSV(String personajeCSV) {
        String[] datos = (personajeCSV.replace("\n", "").split(","));

        return new Personaje(
                Integer.parseInt(datos[0]), datos[1], datos[2], RolPersonaje.valueOf(datos[3])
        );
    }
    
}
