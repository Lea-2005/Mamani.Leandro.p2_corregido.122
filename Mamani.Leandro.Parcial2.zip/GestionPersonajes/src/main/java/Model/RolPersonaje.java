package Model;

public enum RolPersonaje {
    TANQUE,
    MAGO,
    ARQUERO,
    ASESINO,
    SANADOR,
    INGENIERO
}
