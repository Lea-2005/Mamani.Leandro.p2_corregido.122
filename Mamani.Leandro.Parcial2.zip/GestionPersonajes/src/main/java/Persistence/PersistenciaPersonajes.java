package Persistence;

import Model.Personaje;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public interface PersistenciaPersonajes {
    static void guardarPersonajesCSV(List<? extends Personaje> lista, String path) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write(Personaje.toHeaderCSV());
            
            for (Personaje h : lista) {
                bw.write(h.toCSV());
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    static List<Personaje> cargarPersonajesCSV(String path) {
        List<Personaje> toReturn = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String datos;
            br.readLine();

            while ((datos = br.readLine()) != null) {
                toReturn.add(Personaje.fromCSV(datos));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }

    static void serializarPersonajes(List<? extends Personaje> lista, String path) {        
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(lista);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    static List<Personaje> deserializarPersonajes(String path) {
        List<Personaje> toReturn = null;

        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            toReturn = (List<Personaje>) entrada.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }
}
