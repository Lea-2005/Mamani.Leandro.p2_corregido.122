package Model;

public interface CSVSerializable {

    String toCSV();
}
